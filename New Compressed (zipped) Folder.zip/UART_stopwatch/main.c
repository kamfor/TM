#include "include/uart.h"
#include "include/system.h"
#include "include/watchdog.h"
#include "include/menu.h"
#include <stdint.h>
#include <stdlib.h>
#include <stdbool.h>

volatile uint8_t char_buffor = 0;
extern ring_buffer buffor;

#define TICKS_PER_CSEK 16
#define INTERTIMES_SIZE 10
#define DEBOUNCE_VAL 32


extern volatile uint16_t timer_10ms_ticks;
volatile uint8_t position;
volatile uint8_t csecs_counter;
volatile uint8_t num;
volatile uint8_t control_key = '0';
volatile bool to_increment = false;
volatile bool running = false;

char data[12];
uint8_t licznik_miedzyczasow = 0;


typedef volatile struct  {
	uint8_t _1cseconds;
	uint8_t _10cseconds;
	uint8_t _1seconds;
	uint8_t _10seconds;
	uint8_t _1minutes;
	uint8_t _10minutes;
	uint8_t _hours;
} stopwatch_time;
stopwatch_time zeros;
stopwatch_time inter_time[INTERTIMES_SIZE];

void save_intertime(uint8_t);
void display_intertime(uint8_t);

uint8_t temp;

int main(void) {
	watchdog_disable();
    system_init();
    uart_init();
    P1DIR = 0xFF;
    P1OUT = 0x00;


    __enable_interrupt();
	    menu_init();
    while(1){

    	   if(control_key=='s'){
    		   running = !running;
    		   control_key = '0';
    	   } else if (control_key=='z') {
    		   if (running)
    		   {
    			   licznik_miedzyczasow ++;
        		   put(&buffor, "\r");
    			   display_intertime(0);
    			   put(&buffor, "\n\r");

    		   }
			   control_key = '0';
       	   } else if (control_key=='r') {
    		   put(&buffor,"\033c");
    		   put(&buffor, "\n\r");
    		   menu_init();
			   control_key = '0';
			   licznik_miedzyczasow = 0;
			   inter_time[0] = zeros;
       	   }
    	   /* Konwersja licznikow na czas*/
    	   if(inter_time[0]._10cseconds >= 10)
    	   {
    		   inter_time[0]._10cseconds -= 10;
    		   inter_time[0]._1cseconds++;

    		   if(inter_time[0]._1cseconds >= 10)
    		   {
    			   inter_time[0]._1cseconds -= 10;
    			   inter_time[0]._10seconds++;

    			   if(inter_time[0]._10seconds >= 10)
				   {
					   inter_time[0]._10seconds -= 10;
					   inter_time[0]._1seconds++;

	    			   if(inter_time[0]._1seconds >= 6)
					   {
						   inter_time[0]._1seconds -= 6;
						   inter_time[0]._10minutes++;

						   if(inter_time[0]._10minutes >= 10)
						   {
							   inter_time[0]._10minutes -= 10;
							   inter_time[0]._1minutes++;

							   if(inter_time[0]._1minutes >= 6)
							   {
								   inter_time[0]._1minutes -= 6;
								   inter_time[0]._hours++;

								   if(inter_time[0]._1minutes >= 6)
								   {
										inter_time[0]._1minutes -= 6;
										inter_time[0]._hours++;
										inter_time[0]._hours = (inter_time[0]._hours>10) ? 9 : inter_time[0]._hours;
								   }
							   }
						   }
					   }
				   }
    		   }
    	   }


    	   if (to_increment && running) {

    	   /* Wysyanie danych po serialu */



    			data[0] = (char)(inter_time[0]._hours) +'0';
    			data[1] = ':';
    			data[2] = (char)(inter_time[0]._1minutes) +'0';
    			data[3] = (char)(inter_time[0]._10minutes) +'0';
    			data[4] = ':';
    			data[5] = (char)(inter_time[0]._1seconds) +'0';
    			data[6] = (char)(inter_time[0]._10seconds) +'0';
    			data[7] = ':';
    			data[8] = (char)(inter_time[0]._1cseconds) +'0';
    			data[9] = (char)(inter_time[0]._10cseconds) +'0';
    			data[10] = '\r';
    			data[11] = '\0';

    			put(&buffor, data);

			   to_increment = (inter_time[0]._10cseconds <= 10);
    	   }

			temp = pop(&buffor);
			U0TXBUF = temp;
    }
}

#pragma vector=USART0RX_VECTOR
__interrupt void usart0_rx (void)
{
	control_key = RXBUF0;  // odczyt klawisza sterujacego
	P1OUT ^= 0xFF;
	//while (!(IFG1 & UTXIFG0))
	// U0TXBUF = control_key;
}
/*
#pragma vector=USART0TX_VECTOR
__interrupt void usart0_tx (void)
{
	uint8_t temp = pop(&buffor);
	if (temp != 0xFF)
	U0TXBUF = temp;
}*/
// Timer A0 interrupt service routine
#pragma vector=TIMERA0_VECTOR
__interrupt void Timer_A0 (void)
{


		if(running){
			csecs_counter++;
			if(csecs_counter >= TICKS_PER_CSEK) {
				inter_time[0]._10cseconds++;
				csecs_counter = 0;
				to_increment = true;
			}
		}

    TACCTL0&=~CCIFG;
}

void save_intertime(uint8_t index_num)
{
	inter_time[index_num] = inter_time[0];
}

void display_intertime(uint8_t index_num)
{

	if (licznik_miedzyczasow >= 100)
	{
		licznik_miedzyczasow = 0;
	}

	if (licznik_miedzyczasow >= 10)
	{
		data[0] = (char)(licznik_miedzyczasow / 10) + '0';
	}
	else data[0] = ' ';
	data[1] = (char)(licznik_miedzyczasow % 10) + '0';
	data[2] = '\0';

	put(&buffor, data);

	put(&buffor," miedzyczas >");

	data[0] = (char)(inter_time[index_num]._hours) +'0';
	data[1] = ':';
	data[2] = (char)(inter_time[index_num]._1minutes) +'0';
	data[3] = (char)(inter_time[index_num]._10minutes) +'0';
	data[4] = ':';
	data[5] = (char)(inter_time[index_num]._1seconds) +'0';
	data[6] = (char)(inter_time[index_num]._10seconds) +'0';
	data[7] = ':';
	data[8] = (char)(inter_time[index_num]._1cseconds) +'0';
	data[9] = (char)(inter_time[index_num]._10cseconds) +'0';
	data[10] = '\r';
	data[11] = '\0';

	put(&buffor, data);
}


