#include "include/uart.h"
#include "include/system.h"
#include "include/watchdog.h"
#include <stdint.h>
#include <stdbool.h>

volatile uint8_t char_buffor = 0;

#define TICKS_PER_CSEK 16
#define INTERTIMES_SIZE 10
#define DEBOUNCE_VAL 32

extern volatile uint16_t timer_10ms_ticks;
volatile uint8_t position;
volatile uint8_t csecs_counter;
volatile uint8_t num;
volatile bool to_increment = false;

typedef volatile struct  {
	uint8_t cseconds;
	uint8_t seconds;
	uint8_t minutes;
	uint8_t hours;
} stopwatch_time;

stopwatch_time inter_time[INTERTIMES_SIZE];

void save_intertime(uint8_t);
void display_intertime(uint8_t);



int main(void) {
	watchdog_disable();
    system_init();
    uart_init();

    __enable_interrupt();
       while(1){
    	   /* Konwersja licznikow na czas*/
    	   if(inter_time[0].cseconds >= 100)
    	   {
    		   inter_time[0].cseconds -= 100;
    		   inter_time[0].seconds++;

    		   if(inter_time[0].seconds >= 60)
    		   {
    		   		   inter_time[0].seconds -= 60;
    		   		   inter_time[0].minutes++;

    		   		   if(inter_time[0].minutes >= 60)
    		   		   {
    		   			   	inter_time[0].minutes -= 60;
    		   				inter_time[0].hours++;
    		   				inter_time[0].hours = (inter_time[0].hours>10) ? 9 : inter_time[0].hours;
    		   		   }
    		   }


    	   }
    	   if ( to_increment) {
    	   /* Wysyanie danych po serialu */
    		   //uart_puts("Hello world\n");
    	   uart_putchar( (char)(inter_time[0].hours / 10) +'0');
    	   uart_putchar( (char)(inter_time[0].hours % 10) +'0');
    	   uart_putchar(':');

    	   uart_putchar( (char)(inter_time[0].minutes / 10) +'0');
    	   uart_putchar( (char)(inter_time[0].minutes % 10) +'0');
    	   uart_putchar(':');

    	   uart_putchar( (char)(inter_time[0].seconds / 10) +'0');
    	   uart_putchar( (char)(inter_time[0].seconds % 10) +'0');
    	   uart_putchar(':');

    	   uart_putchar( (char)(inter_time[0].cseconds / 10) +'0');
    	   uart_putchar( (char)(inter_time[0].cseconds % 10) +'0');
    	   uart_putchar('\r');

    	   to_increment = (inter_time[0].cseconds < 100);
    	   }

       }
}

/*
#pragma vector=USART0RX_VECTOR
__interrupt void usart0_rx (void)
{
  // USART0 TX buffer ready?
  //U0TXBUF = RXBUF0;                          // RXBUF0 to TXBUF0
	U0TXBUF = (char) 'a';
}
*/
/*
#pragma vector=USART0TX_VECTOR
__interrupt void usart0_tx (void)
{
	  U0TXBUF = (char) num;
}
*/
// Timer A0 interrupt service routine
#pragma vector=TIMERA0_VECTOR
__interrupt void Timer_A0 (void)
{

    	csecs_counter++;
    if(csecs_counter >= TICKS_PER_CSEK) {
    	inter_time[0].cseconds++;
    	csecs_counter = 0;
    	to_increment = true;
    }

    TACCTL0&=~CCIFG;
}

void save_intertime(uint8_t index_num)
{
	inter_time[index_num] = inter_time[0];
}


