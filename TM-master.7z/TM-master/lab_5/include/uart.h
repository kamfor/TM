#ifndef INCLUDE_UART_H_
#define INCLUDE_UART_H_


#include <stdint.h>
#include <msp430.h>


uint8_t uart_init();

uint8_t uart_getchar();

void uart_putchar(uint8_t);

int uart_puts(const char *str);

#endif /* INCLUDE_UART_H_ */
