
#ifndef INCLUDE_TIMERA_H_
#define INCLUDE_TIMERA_H_

#include <msp430.h>


void timerA_init(void);


#endif /* INCLUDE_TIMERA_H_ */
