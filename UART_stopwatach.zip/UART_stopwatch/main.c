#include "include/uart.h"
#include "include/system.h"
#include "include/watchdog.h"
#include "include/menu.h"
#include <stdint.h>
#include <stdlib.h>
#include <stdbool.h>

volatile uint8_t char_buffor = 0;
extern ring_buffer buffor_tx;
extern ring_buffer buffor_rx;

#define TICKS_PER_CSEK 16
#define INTERTIMES_SIZE 10
#define DEBOUNCE_VAL 32


extern volatile uint16_t timer_10ms_ticks;
volatile uint8_t position;
volatile uint8_t csecs_counter;
volatile uint8_t num;
volatile uint8_t control_key = '0';
volatile bool to_increment = false;
volatile bool running = false;

uint8_t licznik_miedzyczasow = 0;


typedef volatile struct  {
	uint8_t _1cseconds;
	uint8_t _10cseconds;
	uint8_t _1seconds;
	uint8_t _10seconds;
	uint8_t _1minutes;
	uint8_t _10minutes;
	uint8_t _hours;
} stopwatch_time;
stopwatch_time zeros;
stopwatch_time inter_time[INTERTIMES_SIZE];

void save_intertime(uint8_t);
void display_intertime(uint8_t);

uint8_t temp;

int main(void) {
	watchdog_disable();
    system_init();
    uart_init();
    menu_init();

    __enable_interrupt();

    while(1){

    		control_key = pop_rx(&buffor_rx);
    	   if(control_key=='s'){
    		   running = !running;
    		   control_key = '0';
    	   } else if (control_key=='z') {
    		   if (running)
    		   {
    			   licznik_miedzyczasow ++;
        		   put_char(&buffor_tx, '\r');
    			   display_intertime(0);
    			   put_string(&buffor_tx, "\n\r");
    		   }
			   control_key = '0';
       	   } else if (control_key=='r') {
    		   put_string(&buffor_tx,"\033c");
    		   put_string(&buffor_tx, "\n\r");
    		   menu_init();
			   control_key = '0';
			   licznik_miedzyczasow = 0;
			   inter_time[0] = zeros;
       	   }
    	   /* Konwersja licznikow na czas*/

			if(csecs_counter >= TICKS_PER_CSEK) {
	    		   inter_time[0]._10cseconds++;
	    		   csecs_counter -= 16;
	    		   to_increment = true;
			}
    	   if(to_increment){

			   if(inter_time[0]._10cseconds >= 10)
			   {
				   inter_time[0]._10cseconds -= 10;
				   inter_time[0]._1cseconds++;

				   if(inter_time[0]._1cseconds >= 10)
				   {
					   inter_time[0]._1cseconds -= 10;
					   inter_time[0]._10seconds++;

					   if(inter_time[0]._10seconds >= 10)
					   {
						   inter_time[0]._10seconds -= 10;
						   inter_time[0]._1seconds++;

						   if(inter_time[0]._1seconds >= 6)
						   {
							   inter_time[0]._1seconds -= 6;
							   inter_time[0]._10minutes++;

							   if(inter_time[0]._10minutes >= 10)
							   {
								   inter_time[0]._10minutes -= 10;
								   inter_time[0]._1minutes++;

								   if(inter_time[0]._1minutes >= 6)
								   {
									   inter_time[0]._1minutes -= 6;
									   inter_time[0]._hours++;

									   if(inter_time[0]._1minutes >= 6)
									   {
											inter_time[0]._1minutes -= 6;
											inter_time[0]._hours++;
											inter_time[0]._hours = (inter_time[0]._hours>10) ? 9 : inter_time[0]._hours;
									   }
								   }
							   }
						   }
					   }
				   }
			   }
    	   }


    	   if (to_increment && running) {

    		   	   put_char(&buffor_tx,(char)(inter_time[0]._hours) +'0');
    		   	   put_char(&buffor_tx,':');
    		   	   put_char(&buffor_tx,(char)(inter_time[0]._1minutes) +'0');
    		   	   put_char(&buffor_tx,(char)(inter_time[0]._10minutes) +'0');
    		   	   put_char(&buffor_tx,':');
				   put_char(&buffor_tx,(char)(inter_time[0]._1seconds) +'0');
    		   	   put_char(&buffor_tx,(char)(inter_time[0]._10seconds) +'0');
				   put_char(&buffor_tx, ':');
    		   	   put_char(&buffor_tx,(char)(inter_time[0]._1cseconds) +'0');
				   put_char(&buffor_tx, (char)(inter_time[0]._10cseconds) +'0');
				   put_char(&buffor_tx, '\r');

			   //to_increment = (inter_time[0]._10cseconds > 10);
				   to_increment = false;
    	   }

		__disable_interrupt();
		if ( !to_increment && (buffor_rx.numofelem == 0)) {
			__bis_SR_register(LPM1_bits + GIE);
		}
		else
			__enable_interrupt();

    } // while end
} // main end

#pragma vector=USART0RX_VECTOR
__interrupt void usart0_rx (void)
{
	put_char_rx(&buffor_rx, RXBUF0);
	__low_power_mode_off_on_exit();
	//control_key = RXBUF0;  // odczyt klawisza sterujacego
	//while (!(IFG1 & UTXIFG0))
	//U0TXBUF = control_key;
}

#pragma vector=USART0TX_VECTOR
__interrupt void usart0_tx (void)
{
	uint8_t temp = pop(&buffor_tx);
	if (temp != 0xFF)
		U0TXBUF = temp;
	__low_power_mode_off_on_exit();
}
// Timer A0 interrupt service routine
#pragma vector=TIMERA0_VECTOR
__interrupt void Timer_A0 (void)
{

		if(running){
			csecs_counter++;
			__low_power_mode_off_on_exit();
		}
		TACCTL0&=~CCIFG;
}

void save_intertime(uint8_t index_num)
{
	inter_time[index_num] = inter_time[0];
}

void display_intertime(uint8_t index_num)
{

	if (licznik_miedzyczasow >= 100)
	{
		licznik_miedzyczasow = 0;
	}

	if (licznik_miedzyczasow >= 10)
	{
		put_char(&buffor_tx,(char)(licznik_miedzyczasow / 10) + '0');
	}
	else put_char(&buffor_tx,' ');
	put_char(&buffor_tx,(char)(licznik_miedzyczasow % 10) + '0');
	put_char(&buffor_tx,'\0');

	put_string(&buffor_tx," miedzyczas >");

	put_char(&buffor_tx,(char)(inter_time[index_num]._hours) +'0');
	put_char(&buffor_tx,':');
	put_char(&buffor_tx,(char)(inter_time[index_num]._1minutes) +'0');
	put_char(&buffor_tx,(char)(inter_time[index_num]._10minutes) +'0');
	put_char(&buffor_tx,':');
	put_char(&buffor_tx,(char)(inter_time[index_num]._1seconds) +'0');
	put_char(&buffor_tx,(char)(inter_time[index_num]._10seconds) +'0');
	put_char(&buffor_tx,':');
	put_char(&buffor_tx,(char)(inter_time[index_num]._1cseconds) +'0');
	put_char(&buffor_tx,(char)(inter_time[index_num]._10cseconds) +'0');
	put_char(&buffor_tx,'\r');
}


