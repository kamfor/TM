
void menu_init();

void menu_run(void);
